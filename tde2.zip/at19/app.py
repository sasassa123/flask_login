from flask import Flask, render_template
from flask_login import LoginManager
from login import login, users, User   
from sensors import sensors
from actuators import actuators

app = Flask(__name__)


app.secret_key = "seila"


login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login.validated_user"  


@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None


app.register_blueprint(login, url_prefix='/')
app.register_blueprint(sensors, url_prefix='/')
app.register_blueprint(actuators, url_prefix='/')


@app.route('/')
def index():
    return render_template('home.html')

@app.route('/login')
def login():
    return render_template('login.html')


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000, debug=True)
